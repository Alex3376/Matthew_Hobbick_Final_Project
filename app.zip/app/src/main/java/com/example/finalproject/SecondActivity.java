// Matthew Hobbick
package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.Loader;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ProgressBar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SecondActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String>{
    Book[] books = new Book[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        RecyclerView list = (RecyclerView) findViewById(R.id.book_list);
        BookListAdapter adapter = new BookListAdapter(books);
        list.setAdapter(adapter);
    }

    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {
        String queryString = "";

        if (args != null) {
            queryString = args.getString("queryString");
        }
        return new BookLoader(this, queryString);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        try {
            JSONObject jsonObject = new JSONObject(data);
            JSONArray itemsArray = jsonObject.getJSONArray("items");
            ArrayList<Book> results = new ArrayList<>();

            int i = 0;
            String title = null;
            String authors = null;
            ProgressBar bar = findViewById(R.id.progress_bar);

            while (i < itemsArray.length()) {
                JSONObject book = itemsArray.getJSONObject(i);
                JSONObject volumeInfo = book.getJSONObject("volumeInfo");
                bar.setProgress(i / itemsArray.length());

                try {
                    Book result = new Book(volumeInfo.getString("title"), volumeInfo.getString("author"), book);
                    results.add(result);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                i++;
            }



        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public class Book {
        String title;
        String author;
        JSONObject book;

        public Book(String title, String author, JSONObject book) {
            this.title = title;
            this.author = author;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public JSONObject getBook() {
            return book;
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }
}