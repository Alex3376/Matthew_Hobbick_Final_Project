package com.example.finalproject;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BookListAdapter extends RecyclerView.Adapter<BookListAdapter.ViewHolder> {
    SecondActivity.Book[] data;

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView mTitle;
        TextView mAuthor;

        public ViewHolder(View view) {
            super(view);
            mTitle = view.findViewById(R.id.title);
            mAuthor = view.findViewById(R.id.author);
        }

        public TextView getmTitle() {
            return mTitle;
        }

        public TextView getmAuthor() {
            return mAuthor;
        }
    }

    public BookListAdapter(SecondActivity.Book[] data) {
        this.data = data;
    }

    @NonNull
    @Override
    public BookListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.book_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BookListAdapter.ViewHolder holder, int position) {
        holder.getmAuthor().setText(data[position].getAuthor());
        holder.getmTitle().setText(data[position].getTitle());
    }

    @Override
    public int getItemCount() {
        return data.length;
    }
}
